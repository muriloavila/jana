<?php
$_ENV['configAvailableInBootstrap'] = isset($_ENV['loadedFromConfig']);
